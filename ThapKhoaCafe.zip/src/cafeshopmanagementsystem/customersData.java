/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafeshopmanagementsystem;

import java.sql.Date;

/**
 *
 * @author gugov
 */
public class customersData {

    private Integer id;
    private Integer customerID;
    private Integer tables;
    private Double total;
    private Date date;
    private String emUsername;

    public customersData(Integer id, Integer customerID, Integer tables, Double total,
             Date date, String emUsername) {
        this.id = id;
        this.customerID = customerID;
        this.tables = tables;
        this.total = total;
        this.date = date;
        this.emUsername = emUsername;
    }

    public Integer getId() {
        return id;
    }

    public Integer getCustomerID() {
        return customerID;
    }
    
    public Integer getTable() {
        return tables;
    }

    public Double getTotal() {
        return total;
    }

    public Date getDate() {
        return date;
    }

    public String getEmUsername() {
        return emUsername;
    }

}
